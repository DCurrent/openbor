
#include <math.h>
#include "types.h"
#include "video.h"
#include "vga.h"
#include "screen.h"
#include "sdlport.h"
#include "opengl.h"
#include "openbor.h"
#include "gfxtypes.h"
#include "gfx.h"
#include "SDL_opengles.h"

extern int videoMode;

#define nextpowerof2(x) pow(2,ceil(log(x)/log(2)))
#define abs(x)			((x<0)?-(x):(x))

#define VIDEO_USE_OPENGL (savedata.usegl[savedata.fullscreen])
#define MUST_USE_BSCREEN 1

s_videomodes stored_videomodes;
SDL_Window* window = NULL;
SDL_Renderer* renderer = NULL;
SDL_Texture* texture = NULL;
SDL_Surface* bscreen = NULL;
static int bytes_per_pixel = 1;
int stretch = 1;
int nativeWidth, nativeHeight; // monitor resolution used in fullscreen mode
static unsigned short glpalette[256]; // for 8bit 
static int viewportWidth, viewportHeight;      // dimensions of display area
static int scaledWidth, scaledHeight;          // dimensions of game screen after scaling
static int textureWidth, textureHeight;        // dimensions of game screen and GL texture
static int xOffset, yOffset;                   // offset of game screen on display area
static int bytesPerPixel;
int opengl = 0;


void initSDL()
{
	const SDL_VideoInfo* video_info;
	int init_flags = SDL_INIT_VIDEO | SDL_INIT_AUDIO | SDL_INIT_TIMER | SDL_INIT_JOYSTICK;

#ifdef CUSTOM_SIGNAL_HANDLER
	init_flags |= SDL_INIT_NOPARACHUTE;
#endif

	if(SDL_Init(init_flags) < 0)
	{
		printf("SDL Failed to Init!!!! (%s)\n", SDL_GetError());
		borExit(0);
	}
	SDL_ShowCursor(SDL_DISABLE);
	atexit(SDL_Quit);

	// Store the monitor's current resolution before setting the video mode for the first time
	video_info = SDL_GetVideoInfo();

	nativeWidth = video_info->current_w;
	nativeHeight = video_info->current_h;
	printf("debug:nativeWidth, nativeHeight, bpp  %d, %d, %d\n", nativeWidth, nativeHeight, video_info->vfmt->BitsPerPixel);


}


static int textureDepths[4] = {16,16,24,32};
static unsigned masks[4][4] = {{0x1F,0x07E0,0xF800,0},{0x1F,0x07E0,0xF800,0},{0xFF,0xFF00,0xFF0000,0},{0xFF,0xFF00,0xFF0000,0}};

int video_set_mode(s_videomodes videomodes)
{
	stored_videomodes = videomodes;
	int b;
	int allocTextureWidth, allocTextureHeight;

	savedata.screen[videoMode][0] = 0;
	savedata.fullscreen = 1;
	bytes_per_pixel = videomodes.pixel;
	b = bytes_per_pixel-1;

	//destroy all
	if(bscreen) SDL_FreeSurface(bscreen);
	bscreen = NULL;
	if(texture) SDL_DestroyTexture(texture);
	texture = NULL;
	if(renderer) SDL_DestroyRenderer(renderer);
	renderer = NULL;
	if(window) SDL_DestroyWindow(window);
	window = NULL;

	if(videomodes.hRes==0 && videomodes.vRes==0)
		return 0;

	viewportWidth = nativeWidth;
	viewportHeight = nativeHeight;
	
	if(!(window = SDL_CreateWindow("OpenBOR", 0, 0, nativeWidth, nativeHeight, SDL_WINDOW_SHOWN|SDL_WINDOW_FULLSCREEN)))
	{
		printf("error: %s\n", SDL_GetError());
		return 0;
	}

	if(!(renderer = SDL_CreateRenderer(window, -1, SDL_RENDERER_ACCELERATED)))
		return 0;

	// now create a texture
	textureWidth = videomodes.hRes;
	textureHeight = videomodes.vRes;

	allocTextureWidth = nextpowerof2(textureWidth);
	allocTextureHeight = nextpowerof2(textureHeight);

	int format = SDL_MasksToPixelFormatEnum (textureDepths[b], masks[b][0], masks[b][1], masks[b][2], masks[b][3]);
	if(!(texture = SDL_CreateTexture(renderer, format, SDL_TEXTUREACCESS_STREAMING, allocTextureWidth, allocTextureHeight)))
		return 0;

	//create a buffer for 8bit mode, masks don't really matter but anyway set them 
	if(bytes_per_pixel==1) bscreen = SDL_AllocSurface(SDL_SWSURFACE, textureWidth, textureHeight, textureDepths[b], masks[b][0], masks[b][1], masks[b][2], masks[b][3]);

	video_clearscreen();

	return 1;
}

void video_fullscreen_flip()
{
	//dummy for now
}

int video_copy_screen(s_screen* src)
{
	void* data;
	int pitch, linew, i, h;
	unsigned char *sp;
	unsigned char *dp;
	SDL_Rect rectdes, rectsrc;
	rectsrc.x=rectsrc.y=0;
	rectsrc.w=textureWidth;
	rectsrc.h=textureHeight;

	linew = src->width*bytes_per_pixel;
	if(bscreen)
	{
		if(src->width!=bscreen->w || src->height!=bscreen->h) return 0;

		if(SDL_MUSTLOCK(bscreen)) SDL_LockSurface(bscreen);
		sp = (unsigned char*)src->data;
		dp = bscreen->pixels;
		h = src->height;
		do{
			//u16pcpy((unsigned short*)dp, sp, glpalette, linew);
			i=linew-1;
			do
			{
			   ((unsigned short*)dp)[i] = glpalette[sp[i]];
			}while(i--);
			sp += linew;
			dp += bscreen->pitch;
		}while(--h);
		data = bscreen->pixels;
		pitch = bscreen->pitch;
	}
	else
	{
		data = src->data;
		pitch = linew;
	}
	SDL_UpdateTexture(texture, &rectsrc, data, pitch);
	if(bscreen && SDL_MUSTLOCK(bscreen)) SDL_UnlockSurface(bscreen);

	if(!stretch)
	{
		rectdes.w = textureWidth;
		rectdes.h = textureHeight;
		rectdes.x = (viewportWidth-rectdes.w)/2;
		rectdes.y = (viewportHeight-rectdes.h)/2;
		printf("debug: @1 %d %d %d %d\n", rectdes.x,rectdes.y,rectdes.w,rectdes.h);
	}
	else if((float)viewportWidth/(float)viewportHeight>(float)textureWidth/(float)textureHeight)
	{
		rectdes.h = viewportHeight;
		rectdes.w = rectdes.h*textureWidth/textureHeight;
		rectdes.x = (viewportWidth-rectdes.w)/2;
		rectdes.y = 0;

		printf("debug: @2 %d %d %d %d\n", rectdes.x,rectdes.y,rectdes.w,rectdes.h);
	}
	else
	{
		rectdes.w = viewportWidth;
		rectdes.h = rectdes.w*textureHeight/textureWidth;
		rectdes.y = (viewportHeight-rectdes.h)/2;
		rectdes.x = 0;
		printf("debug: @3 %d %d %d %d\n", rectdes.x,rectdes.y,rectdes.w,rectdes.h);
	}
	
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);
	SDL_RenderCopy(renderer, texture, &rectsrc, &rectdes);
	SDL_RenderPresent(renderer);
	return 1;
}

void video_clearscreen()
{
	SDL_SetRenderDrawColor(renderer, 0, 0, 0, 255);
	SDL_RenderClear(renderer);
	SDL_RenderPresent(renderer);
}

void video_stretch(int enable)
{
	video_clearscreen();
	stretch = enable;
}

void vga_vwait(void)
{
	static int prevtick = 0;
	int now = SDL_GetTicks();
	int wait = 1000/60 - (now - prevtick);
	if (wait>0)
	{
		SDL_Delay(wait);
	}
	else SDL_Delay(1);
	prevtick = now;
}

void vga_setpalette(unsigned char* palette)
{
	int i;
	for(i=0; i<256; i++)
	{
		glpalette[i] = colour16(palette[0], palette[1], palette[2]);
		palette += 3;
	}
}

//TODO finish this
void vga_set_color_correction(int gm, int br)
{
	/*
    Uint16 ramp[256];
    SDL_CalculateGammaRamp((float)gm/256, ramp);
    SDL_SetWindowGammaRamp(window, ramp, ramp, ramp);*/
}
