
#include "SDL_config.h"

#ifdef __ANDROID__

/* Include the SDL main definition header */
#include "SDL_main.h"

/*******************************************************************************
                 Functions called by JNI
*******************************************************************************/
#include <jni.h>

// Called before SDL_main() to initialize JNI bindings in SDL library
extern "C" void SDL_Android_Init(JNIEnv* env, jclass cls);

// Library init
extern "C" jint JNI_OnLoad(JavaVM* vm, void* reserved);

// Start up the SDL app
extern "C" void Java_org_libsdl_app_SDLActivity_nativeInit(JNIEnv* env, jclass cls, jobject obj)
{
    /* This interface could expand with ABI negotiation, calbacks, etc. */
    SDL_Android_Init(env, cls);

    /* Run the application code! */
    int status;
    char *argv[2];
    argv[0] = strdup("SDL_app");
    argv[1] = NULL;
    status = SDL_main(1, argv);
	
    /* Do not issue an exit or the whole application will terminate instead of just the SDL thread */
    //exit(status);
}

extern "C" void control_update_android_touch(Uint8* touchstates);
extern "C" void Java_org_libsdl_app_SDLActivity_nativeUpdateTouchStates(JNIEnv* env, jclass cls, jbooleanArray states)
{
	jboolean* bstates = env->GetBooleanArrayElements(states,0);
	jsize length=env->GetArrayLength(states);
	static Uint8 bbuf[32]; //enough
	for(int i=0; i<length; i++)
	{
		bbuf[i] = bstates[i];
	}
	control_update_android_touch(bbuf);
	env->ReleaseBooleanArrayElements(states, bstates, 0);
}


/*
extern "C" Uint8* SDL_GetKeyboardState(int *numkeys);
extern "C" void writeToLogFile(const char* fmt, ...);
//key events hanlding
extern "C" void Java_org_openbor_engine_SDLMainActivity_onNativeKeyDown(JNIEnv* env, jclass cls, int keycode)
{
	int nk;
	Uint8* keystate = SDL_GetKeyboardState(&nk);
	writeToLogFile("\nkey down %d / %d\n", keycode, nk);
	if(keycode>0 && keycode<nk)
		keystate[keycode] = 1;
}

extern "C" void Java_org_openbor_engine_SDLMainActivity_onNativeKeyUp(JNIEnv* env, jclass cls, int keycode)
{
	int nk;
	Uint8* keystate = SDL_GetKeyboardState(&nk);
	writeToLogFile("\nkey up %d / %d\n", keycode, nk);
	if(keycode>0 && keycode<nk)
		keystate[keycode] = 0;
}
*/
#endif /* __ANDROID__ */

/* vi: set ts=4 sw=4 expandtab: */
