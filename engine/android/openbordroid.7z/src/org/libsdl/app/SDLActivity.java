package org.libsdl.app;

import javax.microedition.khronos.egl.EGL10;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.egl.EGLContext;
import javax.microedition.khronos.opengles.GL10;
import javax.microedition.khronos.egl.*;

import android.app.*;
import android.content.*;
import android.view.*;
import android.os.*;
import android.util.Log;
import android.graphics.*;
import android.text.method.*;
import android.text.*;
import android.media.*;
import android.hardware.*;
import android.content.*;

import java.lang.*;


/**
    SDL Activity
*/
public class SDLActivity extends Activity {

    // Main components
    private static SDLActivity mSingleton;
    private static SDLSurface mSurface;

    // This is what SDL runs in. It invokes SDL_main(), eventually
    private static Thread mSDLThread;

    public static boolean mIsPaused;

    // Audio
    private static Thread mAudioThread;
    private static AudioTrack mAudioTrack;

    // EGL private objects
    private static EGLContext  mEGLContext;
    private static EGLSurface  mEGLSurface;
    private static EGLDisplay  mEGLDisplay;
    private static EGLConfig   mEGLConfig;
    private static int mGLMajor, mGLMinor;

    // Load the .so
    static {
        //System.loadLibrary("zlib");
        //System.loadLibrary("ogg");
        //System.loadLibrary("vorbis");
        //System.loadLibrary("png");
        System.loadLibrary("sdl");
        System.loadLibrary("openbor");
        System.loadLibrary("main");
    }

    // Setup
    protected void onCreate(Bundle savedInstanceState) {
        //Log.v("SDL", "onCreate()");
        super.onCreate(savedInstanceState);
        
        // So we can call stuff from static callbacks
        mSingleton = this;
        mIsPaused = false;
         requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        // Set up the surface
        mSurface = new SDLSurface(getApplication());
        setContentView(mSurface);
        SurfaceHolder holder = mSurface.getHolder();
    }

    // Events
    protected void onPause() {
        Log.v("SDL", "onPause()");
        super.onPause();
       // SDLActivity.nativePause();
    }

    protected void onResume() {
        Log.v("SDL", "onResume()");
        super.onResume();
        //createEGLContext();
        //SDLActivity.nativeResume();
    }

    protected void onDestroy() {
        super.onDestroy();
        Log.v("SDL", "onDestroy()");
        // Send a quit message to the application
        SDLActivity.nativeQuit();

        // Now wait for the SDL thread to quit
        if (mSDLThread != null) {
            try {
                mSDLThread.join();
            } catch(Exception e) {
                Log.v("SDL", "Problem stopping thread: " + e);
            }
            mSDLThread = null;

            //Log.v("SDL", "Finished waiting for SDL thread");
        }
    }

    // Messages from the SDLMain thread
    static int COMMAND_CHANGE_TITLE = 1;

    // Handler for the messages
    Handler commandHandler = new Handler() {
        public void handleMessage(Message msg) {
            if (msg.arg1 == COMMAND_CHANGE_TITLE) {
                setTitle((String)msg.obj);
            }
        }
    };

    // Send a message from the SDLMain thread
    void sendCommand(int command, Object data) {
        Message msg = commandHandler.obtainMessage();
        msg.arg1 = command;
        msg.obj = data;
        commandHandler.sendMessage(msg);
    }

    // C functions we call
    public static native void nativeInit();
    public static native void nativeQuit();
    public static native void nativePause();
    public static native void nativeResume();
    public static native void onNativeResize(int x, int y, int format);
    public static native void onNativeKeyDown(int keycode);
    public static native void onNativeKeyUp(int keycode);
    public static native void onNativeTouch(int touchDevId, int pointerFingerId,
                                            int action, float x, 
                                            float y, float p);
    public static native void onNativeAccel(float x, float y, float z);
    public static native void nativeRunAudioThread();
    public static native void nativeUpdateTouchStates(boolean[] states);


    // Java functions called from C

    public static boolean createGLContext(int majorVersion, int minorVersion) {
        return initEGL(majorVersion, minorVersion);
    }

    public static void flipBuffers() {
        flipEGL();
    }

    public static void setActivityTitle(String title) {
        // Called from SDLMain() thread and can't directly affect the view
        mSingleton.sendCommand(COMMAND_CHANGE_TITLE, title);
    }

    public static Context getContext() {
        return mSingleton;
    }

    public static void startApp() {
        // Start up the C app thread
        if (mSDLThread == null) {
            mSDLThread = new Thread(new SDLMain(), "SDLThread");
            mSDLThread.start();
        }
        else {
            if (mIsPaused) {
                nativeResume();
                mIsPaused = false;
            }
        }
    }

    // EGL functions
    public static boolean initEGL(int majorVersion, int minorVersion) {
        try {
            if (SDLActivity.mEGLDisplay == null) {
                Log.v("SDL", "Starting up OpenGL ES " + majorVersion + "." + minorVersion);

                EGL10 egl = (EGL10)EGLContext.getEGL();

                EGLDisplay dpy = egl.eglGetDisplay(EGL10.EGL_DEFAULT_DISPLAY);

                int[] version = new int[2];
                egl.eglInitialize(dpy, version);

                int EGL_OPENGL_ES_BIT = 1;
                int EGL_OPENGL_ES2_BIT = 4;
                int renderableType = 0;
                if (majorVersion == 2) {
                    renderableType = EGL_OPENGL_ES2_BIT;
                } else if (majorVersion == 1) {
                    renderableType = EGL_OPENGL_ES_BIT;
                }
                int[] configSpec = {
                    //EGL10.EGL_DEPTH_SIZE,   16,
                    EGL10.EGL_RENDERABLE_TYPE, renderableType,
                    EGL10.EGL_NONE
                };
                EGLConfig[] configs = new EGLConfig[1];
                int[] num_config = new int[1];
                if (!egl.eglChooseConfig(dpy, configSpec, configs, 1, num_config) || num_config[0] == 0) {
                    Log.e("SDL", "No EGL config available");
                    return false;
                }
                EGLConfig config = configs[0];

                SDLActivity.mEGLDisplay = dpy;
                SDLActivity.mEGLConfig = config;
                SDLActivity.mGLMajor = majorVersion;
                SDLActivity.mGLMinor = minorVersion;
            }
             SDLActivity.createEGLSurface();

        } catch(Exception e) {
            Log.v("SDL", e + "");
            for (StackTraceElement s : e.getStackTrace()) {
                Log.v("SDL", s.toString());
            }
            
        }
        return true;
    }

    public static boolean createEGLContext() {
        EGL10 egl = (EGL10)EGLContext.getEGL();
        int EGL_CONTEXT_CLIENT_VERSION=0x3098;
        int contextAttrs[] = new int[] { EGL_CONTEXT_CLIENT_VERSION, SDLActivity.mGLMajor, EGL10.EGL_NONE };
        SDLActivity.mEGLContext = egl.eglCreateContext(SDLActivity.mEGLDisplay, SDLActivity.mEGLConfig, EGL10.EGL_NO_CONTEXT, contextAttrs);
        if (SDLActivity.mEGLContext == EGL10.EGL_NO_CONTEXT) {
            Log.e("SDL", "Couldn't create context");
            return false;
        }
        return true;
    }

    public static boolean createEGLSurface() {
        if (SDLActivity.mEGLDisplay != null && SDLActivity.mEGLConfig != null) {
            EGL10 egl = (EGL10)EGLContext.getEGL();
            if (SDLActivity.mEGLContext == null) createEGLContext();

            Log.v("SDL", "Creating new EGL Surface");
            EGLSurface surface = egl.eglCreateWindowSurface(SDLActivity.mEGLDisplay, SDLActivity.mEGLConfig, SDLActivity.mSurface, null);
            if (surface == EGL10.EGL_NO_SURFACE) {
                Log.e("SDL", "Couldn't create surface");
                return false;
            }

            if (egl.eglGetCurrentContext() != SDLActivity.mEGLContext) {
                if (!egl.eglMakeCurrent(SDLActivity.mEGLDisplay, surface, surface, SDLActivity.mEGLContext)) {
                    Log.e("SDL", "Old EGL Context doesnt work, trying with a new one");
                    // TODO: Notify the user via a message that the old context could not be restored, and that textures need to be manually restored.
                    createEGLContext();
                    if (!egl.eglMakeCurrent(SDLActivity.mEGLDisplay, surface, surface, SDLActivity.mEGLContext)) {
                        Log.e("SDL", "Failed making EGL Context current");
                        return false;
                    }
                }
            }
            SDLActivity.mEGLSurface = surface;
            return true;
        } else {
            Log.e("SDL", "Surface creation failed, display = " + SDLActivity.mEGLDisplay + ", config = " + SDLActivity.mEGLConfig);
            return false;
        }
    }

    // EGL buffer flip
    public static void flipEGL() {
        try {
            EGL10 egl = (EGL10)EGLContext.getEGL();

            egl.eglWaitNative(EGL10.EGL_CORE_NATIVE_ENGINE, null);

            // drawing here

            egl.eglWaitGL();

            egl.eglSwapBuffers(SDLActivity.mEGLDisplay, SDLActivity.mEGLSurface);


        } catch(Exception e) {
            Log.v("SDL", "flipEGL(): " + e);
            for (StackTraceElement s : e.getStackTrace()) {
                Log.v("SDL", s.toString());
            }
        }
    }

    // Audio
    private static Object buf;
    
    public static Object audioInit(int sampleRate, boolean is16Bit, boolean isStereo, int desiredFrames) {
        int channelConfig = isStereo ? AudioFormat.CHANNEL_CONFIGURATION_STEREO : AudioFormat.CHANNEL_CONFIGURATION_MONO;
        int audioFormat = is16Bit ? AudioFormat.ENCODING_PCM_16BIT : AudioFormat.ENCODING_PCM_8BIT;
        int frameSize = (isStereo ? 2 : 1) * (is16Bit ? 2 : 1);
        
        Log.v("SDL", "SDL audio: wanted " + (isStereo ? "stereo" : "mono") + " " + (is16Bit ? "16-bit" : "8-bit") + " " + ((float)sampleRate / 1000f) + "kHz, " + desiredFrames + " frames buffer");
        
        // Let the user pick a larger buffer if they really want -- but ye
        // gods they probably shouldn't, the minimums are horrifyingly high
        // latency already
        desiredFrames = Math.max(desiredFrames, (AudioTrack.getMinBufferSize(sampleRate, channelConfig, audioFormat) + frameSize - 1) / frameSize);
        
        mAudioTrack = new AudioTrack(AudioManager.STREAM_MUSIC, sampleRate,
                channelConfig, audioFormat, desiredFrames * frameSize, AudioTrack.MODE_STREAM);
        
        audioStartThread();
        
        Log.v("SDL", "SDL audio: got " + ((mAudioTrack.getChannelCount() >= 2) ? "stereo" : "mono") + " " + ((mAudioTrack.getAudioFormat() == AudioFormat.ENCODING_PCM_16BIT) ? "16-bit" : "8-bit") + " " + ((float)mAudioTrack.getSampleRate() / 1000f) + "kHz, " + desiredFrames + " frames buffer");
        
        if (is16Bit) {
            buf = new short[desiredFrames * (isStereo ? 2 : 1)];
        } else {
            buf = new byte[desiredFrames * (isStereo ? 2 : 1)]; 
        }
        return buf;
    }
    
    public static void audioStartThread() {
        mAudioThread = new Thread(new Runnable() {
            public void run() {
                mAudioTrack.play();
                nativeRunAudioThread();
            }
        });
        
        // I'd take REALTIME if I could get it!
        mAudioThread.setPriority(Thread.MAX_PRIORITY);
        mAudioThread.start();
    }
    
    public static void audioWriteShortBuffer(short[] buffer) {
        for (int i = 0; i < buffer.length; ) {
            int result = mAudioTrack.write(buffer, i, buffer.length - i);
            if (result > 0) {
                i += result;
            } else if (result == 0) {
                try {
                    Thread.sleep(1);
                } catch(InterruptedException e) {
                    // Nom nom
                }
            } else {
                Log.w("SDL", "SDL audio: error return from write(short)");
                return;
            }
        }
    }
    
    public static void audioWriteByteBuffer(byte[] buffer) {
        for (int i = 0; i < buffer.length; ) {
            int result = mAudioTrack.write(buffer, i, buffer.length - i);
            if (result > 0) {
                i += result;
            } else if (result == 0) {
                try {
                    Thread.sleep(1);
                } catch(InterruptedException e) {
                    // Nom nom
                }
            } else {
                Log.w("SDL", "SDL audio: error return from write(short)");
                return;
            }
        }
    }

    public static void audioQuit() {
        if (mAudioThread != null) {
            try {
                mAudioThread.join();
            } catch(Exception e) {
                Log.v("SDL", "Problem stopping audio thread: " + e);
            }
            mAudioThread = null;

            //Log.v("SDL", "Finished waiting for audio thread");
        }

        if (mAudioTrack != null) {
            mAudioTrack.stop();
            mAudioTrack = null;
        }
    }
}

/**
    Simple nativeInit() runnable
*/
class SDLMain implements Runnable {
    public void run() {
        // Runs SDL_main()
        SDLActivity.nativeInit();

        //Log.v("SDL", "SDL thread terminated");
    }
}


/**
    SDLSurface. This is what we draw on, so we need to know when it's created
    in order to do anything useful. 

    Because of this, that's where we set up the SDL thread
*/
class SDLSurface extends SurfaceView implements SurfaceHolder.Callback, Handler.Callback,
    View.OnKeyListener, View.OnTouchListener, SensorEventListener  {

    // Sensors
    private static SensorManager mSensorManager;

	private Paint paint;
	private Paint painta;


    // Keep track of the surface size to normalize touch events
    private static float mWidth, mHeight;

    private Handler mHandler;

    // Startup    
    public SDLSurface(Context context) {
        super(context);
        getHolder().addCallback(this); 
    
        setFocusable(true);
        setFocusableInTouchMode(true);
        requestFocus();
        setOnKeyListener(this); 
        setOnTouchListener(this);
        setKeepScreenOn(true);

		paint = new Paint();
		paint.setStyle(Paint.Style.STROKE);
		paint.setStrokeWidth(3.0f);
		paint.setARGB(128, 200,255,200);

        painta = new Paint();
		painta.setStyle(Paint.Style.FILL_AND_STROKE);
		painta.setStrokeWidth(3.0f);
		painta.setARGB(224, 255,180,180);

		setWillNotDraw(false);

        for(int i=0; i<maxp; i++)
            pid[i] = -1;

        mHandler = new Handler(this);
        mHandler.sendEmptyMessageDelayed(333, 200);

        mSensorManager = (SensorManager)context.getSystemService("sensor");

    }

    public boolean handleMessage(Message msg)
    {
        if(msg.what==333)
        {/*
            Canvas canvas = null;
            try{
            canvas = getHolder().lockCanvas();
            onDraw(canvas);
            getHolder().unlockCanvasAndPost(canvas);
            }finally{
                ;
            }*/
            mHandler.sendEmptyMessageDelayed(333, 100);
        }
        return false;
    }

    // Called when we have a valid drawing surface
    public void surfaceCreated(SurfaceHolder holder) {
        Log.v("SDL", "surfaceCreated()");
        holder.setType(SurfaceHolder.SURFACE_TYPE_GPU);
        //SDLActivity.createEGLSurface();
        enableSensor(Sensor.TYPE_ACCELEROMETER, true);
    }

    // Called when we lose the surface
    public void surfaceDestroyed(SurfaceHolder holder) {
        Log.v("SDL", "surfaceDestroyed()");
        if (!SDLActivity.mIsPaused) {
            SDLActivity.mIsPaused = true;
            SDLActivity.nativePause();
        }
        enableSensor(Sensor.TYPE_ACCELEROMETER, false);
    }

    // Called when the surface is resized
    public void surfaceChanged(SurfaceHolder holder,
                               int format, int width, int height) {
        Log.v("SDL", "surfaceChanged()");

        int sdlFormat = 0x85151002; // SDL_PIXELFORMAT_RGB565 by default
        switch (format) {
        case PixelFormat.A_8:
            Log.v("SDL", "pixel format A_8");
            break;
        case PixelFormat.LA_88:
            Log.v("SDL", "pixel format LA_88");
            break;
        case PixelFormat.L_8:
            Log.v("SDL", "pixel format L_8");
            break;
        case PixelFormat.RGBA_4444:
            Log.v("SDL", "pixel format RGBA_4444");
            sdlFormat = 0x85421002; // SDL_PIXELFORMAT_RGBA4444
            break;
        case PixelFormat.RGBA_5551:
            Log.v("SDL", "pixel format RGBA_5551");
            sdlFormat = 0x85441002; // SDL_PIXELFORMAT_RGBA5551
            break;
        case PixelFormat.RGBA_8888:
            Log.v("SDL", "pixel format RGBA_8888");
            sdlFormat = 0x86462004; // SDL_PIXELFORMAT_RGBA8888
            break;
        case PixelFormat.RGBX_8888:
            Log.v("SDL", "pixel format RGBX_8888");
            sdlFormat = 0x86262004; // SDL_PIXELFORMAT_RGBX8888
            break;
        case PixelFormat.RGB_332:
            Log.v("SDL", "pixel format RGB_332");
            sdlFormat = 0x84110801; // SDL_PIXELFORMAT_RGB332
            break;
        case PixelFormat.RGB_565:
            Log.v("SDL", "pixel format RGB_565");
            sdlFormat = 0x85151002; // SDL_PIXELFORMAT_RGB565
            break;
        case PixelFormat.RGB_888:
            Log.v("SDL", "pixel format RGB_888");
            // Not sure this is right, maybe SDL_PIXELFORMAT_RGB24 instead?
            sdlFormat = 0x86161804; // SDL_PIXELFORMAT_RGB888
            break;
        default:
            Log.v("SDL", "pixel format unknown " + format);
            break;
        }

        mWidth = (float) width;
        mHeight = (float) height;
        SDLActivity.onNativeResize(width, height, sdlFormat);
        Log.v("SDL", "Window size:" + width + "x"+height);

        SDLActivity.startApp();
    }

    private static final int maxb = 12;
    private static boolean[] touchStates = new boolean[maxb];
        
    private static float[] br = new float[maxb];
    private static float[] bx = new float[maxb];
    private static float[] by = new float[maxb];
	private static String[] bn = new String[maxb];

    // draw a pad here
    public void onDraw(Canvas canvas) {
        Log.v("SDL", "onDraw");
        float w = mWidth;//(float)canvas.getWidth();
        float h = mHeight; //(float)canvas.getHeight();
		//canvas.drawCircle(100.0f, 100.0f, 30.0f, paint);
        if(w==0 || h==0)
        {
            w = (float)canvas.getWidth();
            h = (float)canvas.getHeight();
        }

        float ra=0.15f, rb=ra/1.5f;
        float cx1=ra+rb+rb/5.0f, cy1=1.0f-cx1;
        float cx2=1.0f-cx1, cy2=cy1;
        
        //dpad
        bx[0] = cx1*h;
        by[0] = cy1*h-ra*h;
        br[0] = rb*h;
		bn[0] = "";
        bx[1] = bx[0]+ra*h;
        by[1] = cy1*h;
        br[1] = br[0];
		bn[1] = "";
        bx[2] = bx[0];
        by[2] = cy1*h+ra*h;
        br[2] = br[0];
		bn[2] = "";
        bx[3] = bx[0]-ra*h;
        by[3] = cy1*h;
        br[3] = br[0];
		bn[3] = "";
        //special a2 jump a1
        bx[4] = w-bx[0];
        by[4] = cy2*h-ra*h;
        br[4] = rb*h;
		bn[4] = "sp";
        bx[5] = bx[4]+ra*h;
        by[5] = cy2*h;
        br[5] = br[0];
		bn[5] = "a2";
        bx[6] = bx[4];
        by[6] = cy2*h+ra*h;
        br[6] = br[0];
		bn[6] = "j";
        bx[7] = bx[4]-ra*h;
        by[7] = cy2*h;
        br[7] = br[0];
		bn[7] = "a1";
        //start, esc
        bx[8] = bx[2];
        by[8] = h-by[2];
        br[8] = br[2];
		bn[8] = "st";
        bx[9] = bx[6];
        by[9] = h-by[6];
        br[9] = br[6];
		bn[9] = "es";
        //a3 a4
        bx[10] = w/2.0f-ra*h;
        by[10] = by[2];
        br[10] = br[2];
		bn[10] = "a3";
        bx[11] = w/2.0f+ra*h;
        by[11] = by[6];
        br[11] = br[6];
		bn[11] = "a4";
        for(int i=0; i<maxb; i++){
            canvas.drawCircle(bx[i], by[i], br[i], touchStates[i]?painta:paint);
            Rect b = new Rect();
            String t = bn[i];
            paint.getTextBounds(t, 0, t.length(), b);
            canvas.drawText(t, bx[i]-b.right/2.0f, by[i]+b.bottom/2.0f, paint);
        }

        //canvas.drawText(bx[0] + " x " + by[0] + " x " + br, 10, 10, paint);
	}


	//private static boolean keydownhack = false;

    // Key events
    public boolean onKey(View  v, int keyCode, KeyEvent event) {

        if (keyCode==KeyEvent.KEYCODE_VOLUME_DOWN || keyCode==KeyEvent.KEYCODE_VOLUME_UP)
        {
            return false;
        }

        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            //Log.v("SDL", "key down: " + KeyEvent.keyCodeToString (keyCode) + ", " + event.getEventTime());
            if(keyCode==KeyEvent.KEYCODE_BACK)
                SDLActivity.nativeQuit();
            else
                SDLActivity.onNativeKeyDown(keyCode);
            return true;
        }
        else if (event.getAction() == KeyEvent.ACTION_UP) {
            //Log.v("SDL", "key up: " + KeyEvent.keyCodeToString (keyCode) + ", " + event.getEventTime());
            SDLActivity.onNativeKeyUp(keyCode);
            return true;
        }
        
        return false;
    }

    //pointer states
    private final int maxp = 30;
    private float px[] = new float[maxp];
    private float py[] = new float[maxp];
    private int pid[] = new int[maxp];

    //private static boolean[] touchFilters = new boolean[maxb];
    // Touch events
    public boolean onTouch(View v, MotionEvent event) {
        
        {
             final int touchDevId = event.getDeviceId();
             final int pointerCount = event.getPointerCount();
             // touchId, pointerId, action, x, y, pressure
             int actionPointerIndex = event.getActionIndex(), pointerFingerId;
             int action = event.getActionMasked();

             float x,y,p,s;

             if(action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL)
             {
                for(int i=0; i<maxp; i++)
                    pid[i] = -1;
             }
             else
             {
                 for (int i = 0; i < pointerCount; i++)
                 {
                     pointerFingerId = event.getPointerId(i);
                     x = event.getX(i);
                     y = event.getY(i);
                     if(i!=actionPointerIndex || action == MotionEvent.ACTION_MOVE)
                     {
                         for(int j=0; j<maxp; j++)//handle move
                         {
                            if(pid[j]==pointerFingerId) 
                            {
                                px[j] = x;
                                py[j] = y;
                                break;
                            }
                         }
                     }
                     else if(action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN)
                     {
                         for(int j=0; j<maxp; j++)//handle down
                         {
                            if(pid[j]<0) 
                            {
                                pid[j] = pointerFingerId;
                                px[j] = x;
                                py[j] = y;
                                break;
                            }
                         }
                     }
                     else if(action == MotionEvent.ACTION_POINTER_UP)
                     {
                         for(int j=0; j<maxp; j++)//handle up
                         {
                            if(pid[j]==pointerFingerId) 
                            {
                                pid[j] = -1;
                                break;
                            }
                         }
                     }
                 }
             }
            
            //update button states
            touchStates = new boolean[maxb];
            for (int i = 0; i < maxp; i++) {
                if(pid[i]<0) continue;
                x = px[i];
                y = py[i];
                for(int b=0; b<maxb; b++)
                {
                    float dx = (bx[b]-x);
                    float dy = (by[b]-y);
                    float dr = dx*dx+dy*dy;
                    float r = b<4?br[b]*1.55f:br[b]*1.25f;
                    r*=r;
                    if(dr<=r) touchStates[b] = true;
                }
            }
            SDLActivity.nativeUpdateTouchStates(touchStates);

             if (action == MotionEvent.ACTION_MOVE && pointerCount > 1) {
                // TODO send motion to every pointer if its position has
                // changed since prev event.
                for (int i = 0; i < pointerCount; i++) {
                    pointerFingerId = event.getPointerId(i);
                    x = event.getX(i);
                    y = event.getY(i);
                    p = event.getPressure(i);
                    SDLActivity.onNativeTouch(touchDevId, pointerFingerId, action, x, y, p);
                }
             } else {
                pointerFingerId = event.getPointerId(actionPointerIndex);
                x = event.getX(actionPointerIndex);
                y = event.getY(actionPointerIndex);
                p = event.getPressure(actionPointerIndex);
                SDLActivity.onNativeTouch(touchDevId, pointerFingerId, action, x, y, p);
             }
             
        }

      return true;
   } 

    // Sensor events
    public void enableSensor(int sensortype, boolean enabled) {
        // TODO: This uses getDefaultSensor - what if we have >1 accels?
        if (enabled) {
            mSensorManager.registerListener(this, 
                            mSensorManager.getDefaultSensor(sensortype), 
                            SensorManager.SENSOR_DELAY_GAME, null);
        } else {
            mSensorManager.unregisterListener(this, 
                            mSensorManager.getDefaultSensor(sensortype));
        }
    }
    
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
        // TODO
    }

    public void onSensorChanged(SensorEvent event) {
        
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            SDLActivity.onNativeAccel(event.values[0] / SensorManager.GRAVITY_EARTH,
                                      event.values[1] / SensorManager.GRAVITY_EARTH,
                                      event.values[2] / SensorManager.GRAVITY_EARTH);
        }
    }

}

